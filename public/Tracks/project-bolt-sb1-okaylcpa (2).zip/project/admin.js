// State management
let tracks = [];
let courses = {};
let tasks = {};

// DOM Elements
const trackSection = document.getElementById('tracks-section');
const courseSection = document.getElementById('courses-section');
const taskSection = document.getElementById('tasks-section');
const tabButtons = document.querySelectorAll('.tab-button');
const trackModal = document.getElementById('track-modal');
const courseModal = document.getElementById('course-modal');
const taskModal = document.getElementById('task-modal');

// Initialize Lucide icons
lucide.createIcons();

// Tab switching
tabButtons.forEach(button => {
  button.addEventListener('click', () => {
    const tabName = button.dataset.tab;
    
    // Update active tab button
    tabButtons.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    
    // Update active section
    document.querySelectorAll('.admin-section').forEach(section => {
      section.classList.remove('active');
    });
    document.getElementById(`${tabName}-section`).classList.add('active');
  });
});

// Load initial data
async function init() {
  tracks = await API.getTracks();
  renderTracks();
  updateTrackSelectors();
}

// Render functions
function renderTracks() {
  const grid = document.getElementById('tracks-grid');
  grid.innerHTML = tracks.map(track => `
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">${track.name}</h3>
        <div class="admin-card-actions">
          <button class="action-button edit-button" onclick="editTrack('${track.id}')">
            <i data-lucide="edit"></i>
          </button>
          <button class="action-button delete-button" onclick="deleteTrack('${track.id}')">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
      </div>
      <div class="card-icon">
        <i data-lucide="${track.icon === 'web' ? 'globe' : track.icon === 'embedded' ? 'cpu' : 'code-2'}"></i>
      </div>
    </div>
  `).join('');
  lucide.createIcons();
}

function renderCourses(trackId) {
  const grid = document.getElementById('courses-grid');
  const trackCourses = courses[trackId] || [];
  
  grid.innerHTML = trackCourses.map(course => `
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">${course.name}</h3>
        <div class="admin-card-actions">
          <button class="action-button edit-button" onclick="editCourse('${course.id}')">
            <i data-lucide="edit"></i>
          </button>
          <button class="action-button delete-button" onclick="deleteCourse('${course.id}')">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');
  lucide.createIcons();
}

function renderTasks(courseId) {
  const grid = document.getElementById('tasks-grid');
  const courseTasks = tasks[courseId] || [];
  
  grid.innerHTML = courseTasks.map(task => `
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">${task.name}</h3>
        <div class="admin-card-actions">
          <button class="action-button edit-button" onclick="editTask('${task.id}')">
            <i data-lucide="edit"></i>
          </button>
          <button class="action-button delete-button" onclick="deleteTask('${task.id}')">
            <i data-lucide="trash-2"></i>
          </button>
        </div>
      </div>
      <div class="task-meta">
        <div class="meta-item">
          <i data-lucide="clock"></i>
          <span>${task.estimatedTime}</span>
        </div>
        <div class="meta-item">
          <i data-lucide="star"></i>
          <span>${task.score} points</span>
        </div>
      </div>
    </div>
  `).join('');
  lucide.createIcons();
}

// Update selectors
function updateTrackSelectors() {
  const courseTrackSelect = document.getElementById('course-track-select');
  const taskTrackSelect = document.getElementById('task-track-select');
  
  const trackOptions = tracks.map(track => 
    `<option value="${track.id}">${track.name}</option>`
  ).join('');
  
  courseTrackSelect.innerHTML = '<option value="">Select a track...</option>' + trackOptions;
  taskTrackSelect.innerHTML = '<option value="">Select a track...</option>' + trackOptions;
}

// Load data based on selections
async function loadTrackCourses() {
  const trackId = document.getElementById('course-track-select').value;
  if (!trackId) return;
  
  if (!courses[trackId]) {
    courses[trackId] = await API.getCourses(trackId);
  }
  renderCourses(trackId);
}

async function loadTaskTrackCourses() {
  const trackId = document.getElementById('task-track-select').value;
  if (!trackId) return;
  
  if (!courses[trackId]) {
    courses[trackId] = await API.getCourses(trackId);
  }
  
  const courseSelect = document.getElementById('task-course-select');
  courseSelect.innerHTML = '<option value="">Select a course...</option>' +
    courses[trackId].map(course => 
      `<option value="${course.id}">${course.name}</option>`
    ).join('');
}

async function loadCourseTasks() {
  const courseId = document.getElementById('task-course-select').value;
  if (!courseId) return;
  
  if (!tasks[courseId]) {
    tasks[courseId] = await API.getTasks(courseId);
  }
  renderTasks(courseId);
}

// Modal functions
function showTrackModal() {
  document.getElementById('track-modal-title').textContent = 'Add Track';
  document.getElementById('track-form').reset();
  trackModal.classList.add('active');
}

function closeTrackModal() {
  trackModal.classList.remove('active');
}

function showCourseModal() {
  document.getElementById('course-modal-title').textContent = 'Add Course';
  document.getElementById('course-form').reset();
  courseModal.classList.add('active');
}

function closeCourseModal() {
  courseModal.classList.remove('active');
}

function showTaskModal() {
  document.getElementById('task-modal-title').textContent = 'Add Task';
  document.getElementById('task-form').reset();
  taskModal.classList.add('active');
}

function closeTaskModal() {
  taskModal.classList.remove('active');
}

// Form handlers
async function handleTrackSubmit(event) {
  event.preventDefault();
  const formData = {
    id: document.getElementById('track-id').value || Date.now().toString(),
    name: document.getElementById('track-name').value,
    icon: document.getElementById('track-icon').value
  };
  
  // In a real app, this would be an API call
  if (formData.id) {
    const index = tracks.findIndex(t => t.id === formData.id);
    if (index !== -1) {
      tracks[index] = formData;
    } else {
      tracks.push(formData);
    }
  }
  
  renderTracks();
  updateTrackSelectors();
  closeTrackModal();
}

async function handleCourseSubmit(event) {
  event.preventDefault();
  const trackId = document.getElementById('course-track-select').value;
  const formData = {
    id: document.getElementById('course-id').value || Date.now().toString(),
    name: document.getElementById('course-name').value
  };
  
  // In a real app, this would be an API call
  if (!courses[trackId]) {
    courses[trackId] = [];
  }
  
  if (formData.id) {
    const index = courses[trackId].findIndex(c => c.id === formData.id);
    if (index !== -1) {
      courses[trackId][index] = formData;
    } else {
      courses[trackId].push(formData);
    }
  }
  
  renderCourses(trackId);
  closeCourseModal();
}

async function handleTaskSubmit(event) {
  event.preventDefault();
  const courseId = document.getElementById('task-course-select').value;
  const formData = {
    id: document.getElementById('task-id').value || Date.now().toString(),
    name: document.getElementById('task-name').value,
    description: document.getElementById('task-description').value,
    estimatedTime: document.getElementById('task-time').value,
    score: parseInt(document.getElementById('task-score').value),
    dataLink: document.getElementById('task-data-link').value,
    submissionLink: document.getElementById('task-submission-link').value
  };
  
  // In a real app, this would be an API call
  if (!tasks[courseId]) {
    tasks[courseId] = [];
  }
  
  if (formData.id) {
    const index = tasks[courseId].findIndex(t => t.id === formData.id);
    if (index !== -1) {
      tasks[courseId][index] = formData;
    } else {
      tasks[courseId].push(formData);
    }
  }
  
  renderTasks(courseId);
  closeTaskModal();
}

// Edit functions
function editTrack(id) {
  const track = tracks.find(t => t.id === id);
  if (!track) return;
  
  document.getElementById('track-modal-title').textContent = 'Edit Track';
  document.getElementById('track-id').value = track.id;
  document.getElementById('track-name').value = track.name;
  document.getElementById('track-icon').value = track.icon;
  
  trackModal.classList.add('active');
}

function editCourse(id) {
  const trackId = document.getElementById('course-track-select').value;
  const course = courses[trackId]?.find(c => c.id === id);
  if (!course) return;
  
  document.getElementById('course-modal-title').textContent = 'Edit Course';
  document.getElementById('course-id').value = course.id;
  document.getElementById('course-name').value = course.name;
  
  courseModal.classList.add('active');
}

function editTask(id) {
  const courseId = document.getElementById('task-course-select').value;
  const task = tasks[courseId]?.find(t => t.id === id);
  if (!task) return;
  
  document.getElementById('task-modal-title').textContent = 'Edit Task';
  document.getElementById('task-id').value = task.id;
  document.getElementById('task-name').value = task.name;
  document.getElementById('task-description').value = task.description;
  document.getElementById('task-time').value = task.estimatedTime;
  document.getElementById('task-score').value = task.score;
  document.getElementById('task-data-link').value = task.dataLink;
  document.getElementById('task-submission-link').value = task.submissionLink;
  
  taskModal.classList.add('active');
}

// Delete functions
function deleteTrack(id) {
  if (!confirm('Are you sure you want to delete this track?')) return;
  
  const index = tracks.findIndex(t => t.id === id);
  if (index !== -1) {
    tracks.splice(index, 1);
    delete courses[id];
    renderTracks();
    updateTrackSelectors();
  }
}

function deleteCourse(id) {
  if (!confirm('Are you sure you want to delete this course?')) return;
  
  const trackId = document.getElementById('course-track-select').value;
  const index = courses[trackId]?.findIndex(c => c.id === id);
  if (index !== -1) {
    courses[trackId].splice(index, 1);
    delete tasks[id];
    renderCourses(trackId);
  }
}

function deleteTask(id) {
  if (!confirm('Are you sure you want to delete this task?')) return;
  
  const courseId = document.getElementById('task-course-select').value;
  const index = tasks[courseId]?.findIndex(t => t.id === id);
  if (index !== -1) {
    tasks[courseId].splice(index, 1);
    renderTasks(courseId);
  }
}

// Initialize the page
init();